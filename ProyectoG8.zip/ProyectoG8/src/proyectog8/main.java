package proyectog8;

public class main {

    public static void main(String[] args) {
        Menu m=new Menu();
        m.mostrarMenu();
       
        //Primer commit de montero 
    }
    
}
